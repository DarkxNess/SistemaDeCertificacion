# Galeria-de-Imagenes-Efecto-Fade
Galería de imágenes con el asombroso efecto Ovelay  //Las imágenes están muy pesadas se recomienda optimizarlas para web

[Da Click Aquí para apoyarme en YouTube](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)

[Tutorial: https://youtu.be/Ff8Acay5oXI](https://youtu.be/Ff8Acay5oXI)

![AlexCG Design](https://github.com/AlexCGDesign/Galeria-de-Imagenes-Efecto-Fade/blob/master/Galeria%20con%20efecto%20Overlay/img/Galeria%20de%20imagenes.png)

### Hecho por: [AlexCG Design](https://www.youtube.com/c/AlexCGDesign?sub_confirmation=1)
